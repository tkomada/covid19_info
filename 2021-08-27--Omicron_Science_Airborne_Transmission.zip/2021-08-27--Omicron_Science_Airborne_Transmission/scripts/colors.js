var cColors = new Array(
	{ text:'#000000', back:'#FFFFFF', text_h:'#000000', back_h:'#FFFF00', toc:'#FFFFFF', ruby:'#0000FF', ruby_h:'#C40000', border:'#009500', border_h:'#000000', th_a:'#00FF00', td_a:'#FFFF00', tb_a:'#FF0000' },
	{ text:'#000000', back:'#FDFFC3', text_h:'#000000', back_h:'#BBFFBB', toc:'#FDFFC3', ruby:'#0000FF', ruby_h:'#0000FF', border:'#FF1493', border_h:'#000000', th_a:'#FFFF00', td_a:'#00FF00', tb_a:'#0000FF' },
	{ text:'#000000', back:'#FECBDF', text_h:'#000000', back_h:'#D8D8D8', toc:'#FECBDF', ruby:'#0000CD', ruby_h:'#0000CD', border:'#D70035', border_h:'#000000', th_a:'#00FF00', td_a:'#FFFF00', tb_a:'#FF0000' },
	{ text:'#000000', back:'#CCEEFF', text_h:'#000000', back_h:'#EBF5A0', toc:'#CCEEFF', ruby:'#0000CD', ruby_h:'#0000CD', border:'#D70035', border_h:'#000000', th_a:'#00FF00', td_a:'#FFFF00', tb_a:'#FFFF00' },
	{ text:'#FFFF00', back:'#000000', text_h:'#FFFF00', back_h:'#0000FF', toc:'#000000', ruby:'#00FF00', ruby_h:'#00FF00', border:'#00FF00', border_h:'#FFFF00', th_a:'#D20000', td_a:'#0000FF', tb_a:'#FFFF00' },
	{ text:'#FFFFFF', back:'#00006F', text_h:'#FFFFFF', back_h:'#8B4513', toc:'#00006F', ruby:'#F4F400', ruby_h:'#00FF00', border:'#00FFFF', border_h:'#FFFF00', th_a:'#CC0000', td_a:'#008000', tb_a:'#FFFF00' },
	{ text:'#000000', back:'#D8D8D8', text_h:'#000000', back_h:'#FFB3D9', toc:'#D8D8D8', ruby:'#0000FF', ruby_h:'#0000FF', border:'#D70035', border_h:'#000000', th_a:'#00FF00', td_a:'#00FFFF', tb_a:'#FF0000' },
	{ text:'#000000', back:'#009D00', text_h:'#000000', back_h:'#C0C0C0', toc:'#009D00', ruby:'#800040', ruby_h:'#800040', border:'#D70035', border_h:'#000000', th_a:'#00FF00', td_a:'#FF8080', tb_a:'#FFFF00' }
) ;

var cSelectColor = 
{
	text:'black',
	back:'#8F8'
} ;
